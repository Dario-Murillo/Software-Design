﻿global using BoDi;
global using FluentAssertions;
global using LabCICD.Web.AcceptanceTests.Pages;
global using Microsoft.Playwright;
global using TechTalk.SpecFlow;