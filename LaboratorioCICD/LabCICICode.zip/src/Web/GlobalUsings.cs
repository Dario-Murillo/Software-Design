global using Ardalis.GuardClauses;
global using LabCICD.Web.Infrastructure;
global using MediatR;
