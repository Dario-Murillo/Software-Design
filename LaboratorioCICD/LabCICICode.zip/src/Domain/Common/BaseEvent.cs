﻿using MediatR;

namespace LabCICD.Domain.Common;
public abstract class BaseEvent : INotification
{
}
