﻿using Microsoft.AspNetCore.Identity;

namespace LabCICD.Infrastructure.Identity;
public class ApplicationUser : IdentityUser
{
}
