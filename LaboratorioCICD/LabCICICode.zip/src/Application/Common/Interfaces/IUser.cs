﻿namespace LabCICD.Application.Common.Interfaces;

public interface IUser
{
    string? Id { get; }
}
