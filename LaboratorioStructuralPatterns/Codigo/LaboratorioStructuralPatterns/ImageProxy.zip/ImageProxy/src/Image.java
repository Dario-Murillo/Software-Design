public interface Image
{
    void showImage();
}