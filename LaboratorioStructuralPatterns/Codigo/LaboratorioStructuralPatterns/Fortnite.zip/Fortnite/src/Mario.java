public class Mario {
  public int jumpAttack() {
    System.out.println("Mamamia!");
    return 23;
  }
}
