public abstract class Notifier {
    public abstract void send(String message);
}
