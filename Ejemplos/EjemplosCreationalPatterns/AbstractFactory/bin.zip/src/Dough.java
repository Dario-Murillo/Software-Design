public interface Dough {
	public String toString();
}
