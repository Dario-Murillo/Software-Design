public interface Pepperoni {
	public String toString();
}
