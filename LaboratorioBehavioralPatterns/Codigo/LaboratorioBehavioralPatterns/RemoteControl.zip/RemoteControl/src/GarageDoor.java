/*
 * Dario Murillo Chaverri C15406
 * José Fabián Guzmán González C23660 
 */
public class GarageDoor {
    public String up() {
        return "Garage door is up";
    }

    public String down() {
        return "Garage door is down";
    }

    public String stop() {
        return "Garage door movement is stopped";
    }

    public String lightOn() {
        return "Garage door light is on";
    }

    public String lightOff() {
        return "Garage door light is off";
    }
}
