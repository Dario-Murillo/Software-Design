/*
 * Dario Murillo Chaverri C15406
 * José Fabián Guzmán González C23660 
 */

public enum Pais {
    USA,
    UK,
    CostaRica
}