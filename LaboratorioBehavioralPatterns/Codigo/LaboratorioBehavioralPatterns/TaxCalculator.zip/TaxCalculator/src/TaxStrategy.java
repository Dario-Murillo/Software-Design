/*
 * Dario Murillo Chaverri C15406
 * José Fabián Guzmán González C23660 
 */

public abstract class TaxStrategy {
  public abstract double Tax(double total);
}
